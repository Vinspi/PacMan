Ceci est le r�pertoire principal du rendu de projet G�nie Logiciel par le groupe compos� de :

	- VINCENT Pierre
	- FAUCONNIER Axel
	- LOIGNON Lucas
	- CAUET Christopher
	- DEUTSCH R�mi

Ce r�pertoire contient :

	- le dossier doc qui regroupe tous les document de conception du projet.
	- le dossier releases qui contient les release pour les plateformes linux et windows.
	- le dossier Editeur_de_niveau qui contient le logiciel de cr�ation de niveau.
	- le dossier sources qui contient tous les fichiers sources du projet.