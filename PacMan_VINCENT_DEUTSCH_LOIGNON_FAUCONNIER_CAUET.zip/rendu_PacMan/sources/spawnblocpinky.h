#ifndef SPAWNBLOCPINKY_H
#define SPAWNBLOCPINKY_H
#include "blocitem.h"

class SpawnBlocPinky : public BlocItem
{
public:
    SpawnBlocPinky();
};

#endif // SPAWNBLOCPINKY_H
