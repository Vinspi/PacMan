/********************************************************************************
** Form generated from reading UI file 'vuecreationprofil.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VUECREATIONPROFIL_H
#define UI_VUECREATIONPROFIL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_vuecreationprofil
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QLabel *label_4;
    QTextEdit *pseudo_input;
    QLabel *label_2;
    QTextEdit *textEdit_2;
    QPushButton *submit_form;

    void setupUi(QWidget *vuecreationprofil)
    {
        if (vuecreationprofil->objectName().isEmpty())
            vuecreationprofil->setObjectName(QStringLiteral("vuecreationprofil"));
        vuecreationprofil->resize(1280, 800);
        vuecreationprofil->setAutoFillBackground(false);
        vuecreationprofil->setStyleSheet(QLatin1String("background: linear-gradient(45deg, #dca 12%, transparent 0, transparent 88%, #dca 0),\n"
"    linear-gradient(135deg, transparent 37%, #a85 0, #a85 63%, transparent 0),\n"
"    linear-gradient(45deg, transparent 37%, #dca 0, #dca 63%, transparent 0) #753;\n"
"    background-size: 25px 25px;"));
        verticalLayoutWidget = new QWidget(vuecreationprofil);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 0, 1281, 801));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(verticalLayoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setStyleSheet(QStringLiteral("color: brown; font-weight: 900; font-size: 40px; border: 2px dotted black; background-color: white; padding: 20px; border-radius: 10px ;"));

        verticalLayout->addWidget(label_3, 0, Qt::AlignHCenter|Qt::AlignVCenter);

        label_4 = new QLabel(verticalLayoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setStyleSheet(QStringLiteral("color: brown; font-weight: 900; font-size: 15px; border: 2px solid black; background-color: white; padding: 20px; border-radius: 10px ;"));

        verticalLayout->addWidget(label_4, 0, Qt::AlignHCenter|Qt::AlignVCenter);

        pseudo_input = new QTextEdit(verticalLayoutWidget);
        pseudo_input->setObjectName(QStringLiteral("pseudo_input"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pseudo_input->sizePolicy().hasHeightForWidth());
        pseudo_input->setSizePolicy(sizePolicy);
        pseudo_input->setMinimumSize(QSize(50, 30));
        pseudo_input->setMaximumSize(QSize(500, 30));
        pseudo_input->setStyleSheet(QStringLiteral("background-color: white; color: black;"));

        verticalLayout->addWidget(pseudo_input, 0, Qt::AlignHCenter|Qt::AlignVCenter);

        label_2 = new QLabel(verticalLayoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setStyleSheet(QStringLiteral("color: brown; font-weight: 900; font-size: 15px; border: 2px solid black; background-color: white; padding: 20px; border-radius: 10px ;"));

        verticalLayout->addWidget(label_2, 0, Qt::AlignHCenter|Qt::AlignVCenter);

        textEdit_2 = new QTextEdit(verticalLayoutWidget);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        textEdit_2->setMinimumSize(QSize(50, 30));
        textEdit_2->setMaximumSize(QSize(500, 30));
        textEdit_2->setStyleSheet(QStringLiteral("background-color: white; color: black;"));

        verticalLayout->addWidget(textEdit_2, 0, Qt::AlignHCenter|Qt::AlignVCenter);

        submit_form = new QPushButton(verticalLayoutWidget);
        submit_form->setObjectName(QStringLiteral("submit_form"));
        submit_form->setMinimumSize(QSize(400, 0));
        submit_form->setMaximumSize(QSize(500, 16777215));
        submit_form->setStyleSheet(QLatin1String(" QPushButton#submit_form{\n"
"    color: brown; font-weight: 900; font-size: 20px; border: 2px dotted black; background-color: white; padding: 20px; border-radius: 10px ;\n"
" }\n"
"\n"
" QPushButton#submit_form:hover {\n"
"     background-color: rgb(255, 204, 0);\n"
"	 color: black;\n"
" }\n"
"\n"
" QPushButton#submit_form:pressed {\n"
"     background-color: 	rgb(255, 128, 0);\n"
"	 color: black;\n"
" }"));

        verticalLayout->addWidget(submit_form, 0, Qt::AlignHCenter|Qt::AlignVCenter);


        retranslateUi(vuecreationprofil);

        QMetaObject::connectSlotsByName(vuecreationprofil);
    } // setupUi

    void retranslateUi(QWidget *vuecreationprofil)
    {
        vuecreationprofil->setWindowTitle(QApplication::translate("vuecreationprofil", "Form", nullptr));
        label_3->setText(QApplication::translate("vuecreationprofil", "CREATION DE PROFIL", nullptr));
        label_4->setText(QApplication::translate("vuecreationprofil", "ENTREZ VOTRE PSEUDO", nullptr));
        label_2->setText(QApplication::translate("vuecreationprofil", "ENTREZ VOTRE EMAIL", nullptr));
        submit_form->setText(QApplication::translate("vuecreationprofil", "CREER MON PROFIL", nullptr));
    } // retranslateUi

};

namespace Ui {
    class vuecreationprofil: public Ui_vuecreationprofil {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VUECREATIONPROFIL_H
