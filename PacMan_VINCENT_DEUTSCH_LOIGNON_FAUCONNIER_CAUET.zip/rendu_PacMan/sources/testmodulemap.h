#ifndef TESTMODULEMAP_H
#define TESTMODULEMAP_H


class TestModuleMap
{
public:
    TestModuleMap();
    void assertMap(int assert);
};

#endif // TESTMODULEMAP_H
