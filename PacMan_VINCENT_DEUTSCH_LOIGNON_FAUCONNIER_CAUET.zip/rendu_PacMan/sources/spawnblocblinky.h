#ifndef SPAWNBLOCBLINKY_H
#define SPAWNBLOCBLINKY_H
#include "blocitem.h"

class SpawnBlocBlinky : public BlocItem
{
public:
    SpawnBlocBlinky();
};

#endif // SPAWNBLOCBLINKY_H
