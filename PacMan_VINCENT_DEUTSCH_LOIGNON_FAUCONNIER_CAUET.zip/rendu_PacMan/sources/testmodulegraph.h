#ifndef TESTMODULEGRAPH_H
#define TESTMODULEGRAPH_H
#include "graph.h";

class TestModuleGraph
{
public:
    TestModuleGraph();
    void assertGraph(int assert);
};

#endif // TESTMODULEGRAPH_H
