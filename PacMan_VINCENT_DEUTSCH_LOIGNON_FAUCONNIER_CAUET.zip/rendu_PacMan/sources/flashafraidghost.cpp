#include "flashafraidghost.h"

FlashAfraidGhost::FlashAfraidGhost() : Ghost("../PacMan/graphics_pacman/Flash_afraid_ghost.png")
{
    setVitesse(2);
}

void FlashAfraidGhost::nextIAMove(Graph *graph_control,Entity *e){

}
