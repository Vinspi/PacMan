#ifndef SPAWNBLOC_H
#define SPAWNBLOC_H
#include "blocitem.h"

class SpawnBlocClyde : public BlocItem
{
public:
    SpawnBlocClyde();
};

#endif // SPAWNBLOC_H
