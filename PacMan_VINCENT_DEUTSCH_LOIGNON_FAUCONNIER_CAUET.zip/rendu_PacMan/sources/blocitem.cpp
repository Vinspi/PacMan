#include "blocitem.h"

BlocItem::BlocItem() : QGraphicsPixmapItem()
{

}


//QPainterPath BlocItem::shape() const  {
//    QPainterPath path;
//    path.addRect(0,0,32,32);
//    return path;
//}

//QRectF BlocItem::boundingRect() const{
//    return QRectF(0,0,30,30);
//}

