#ifndef BLOCITEM_H
#define BLOCITEM_H
#include <QGraphicsPixmapItem>
#include <QPainter>

class BlocItem : public QGraphicsPixmapItem
{
public:
    BlocItem();
    //QPainterPath shape() const;
    //QRectF boundingRect() const;

};

#endif // BLOCITEM_H
