#ifndef SPAWNBLOCINKY_H
#define SPAWNBLOCINKY_H
#include "blocitem.h"

class SpawnBlocInky : public BlocItem
{
public:
    SpawnBlocInky();
};

#endif // SPAWNBLOCINKY_H
