#include "pacman.h"

PacMan::PacMan() : Entity("../PacMan/graphics_pacman/Pacman.png")
{
    setVitesse(4);
}


