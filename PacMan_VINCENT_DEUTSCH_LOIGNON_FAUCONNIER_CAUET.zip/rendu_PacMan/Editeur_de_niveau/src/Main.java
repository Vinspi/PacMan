/**
 * Created by vinspi on 07/11/17.
 */
public class Main {

    public static void main(String[] args) {
        MainWindow mw = new MainWindow(24,24);

    }

}
