Ceci est le readme de l'�diteur de niveau fait � l'occasion du d�veloppement du jeu de Pac-Man.
Condition d'utilisation : avoir jre 7 ou plus install� sur le syst�me

Le logiciel est un executable jar.

Lancement :
	- sous linux lancer java -jar Editeur_de_niveau.jar
	- sous Windows la m�thode pr�c�dente fonctione mais en g�n�ral un double-clic sur l'ex�cutable suffit � le lancer.

Utilisation :
	- touche n : mode normal
	- touche b : mode edition spawn blinky
	- touche i : mode edition spawn inky
	- touche p : mode edition spawn pinky
	- touche c : mode edition spawn clyde
	- touche j : mode edition spawn Pac-Man
	- touche n : mode edition super-dot
	- bouton "enregistrer" en bas : enregistre le niveau au format xml dans un fichier xml_level.xml
